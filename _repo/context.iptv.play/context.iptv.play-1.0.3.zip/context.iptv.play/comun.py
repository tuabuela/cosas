# -*- coding: utf-8 -*-
#
# Copyright (C) 2018 nadie
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import xbmc
import xbmcgui
import xbmcvfs
import re

def amain(que):
	channel_name = xbmc.getInfoLabel("ListItem.ChannelName")
	if not channel_name:
		channel_name = sys.listitem.getLabel()
	#window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
	#xbmc.getInfoLabel('Container(9000).ListItem.Property(id)') 
	#control = window.getControl(12000)
	#vi = control.getHeight()
	#xbmc.executebuiltin("Notification(\"Hello context items!\", \"%s\")" % vi)
	if channel_name:
		f = xbmcvfs.File("special://profile/addon_data/pvr.iptvsimple/iptv.m3u.cache","rb")
		read = f.read().splitlines()
		f.close()
		encontrado = 0
		url = ""
		for line in read:
			line = line.decode('iso-8859-1').encode('utf8')
			#if re.search(',%s$' % channel_name, line):
			if line[-len(channel_name):] == channel_name:
				#xbmc.executebuiltin("Notification(\"Hello context items!\", \"%s\")" % line)
				encontrado = 1
			if encontrado == 1 and line[0:4]=="http":
				encontrado = 0
				url = line
		if len(url) > 0:
			url = url + "/%s" % que
			#xbmc.executebuiltin("Notification(\"Hello context items!\", \"%s\")" % url[15:])
			xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.f4mTester/?streamtype=%s&amp;name=%s;url=%s)' % (que,channel_name,url))

#if __name__ == '__main__':
	#main()
